using UnityEngine;

public static class Layers
{
    public const string RuntimeColliderTag = "RuntimeCollider";
    public const string RuntimeLightTag = "RuntimeLight";
    public const string MainColliderTag = "MainCollider";
    public const string MainCameraTag = "MainCamera";

    public const string VideoCameraTag = "VideoCamera";
    public const string AudioObjectTag = "Audio";

    public static readonly int DefaultLayer = LayerMask.NameToLayer("Default");
    public static readonly int UiLayer = LayerMask.NameToLayer("UI");

    public static readonly int RenderTargetLayer = LayerMask.NameToLayer("RenderTarget");

    public static readonly int EnvironmentLayer = LayerMask.NameToLayer("Environment");
    public static readonly int SelectableLayer = LayerMask.NameToLayer("Selectable");
    public static readonly int NavigationLayer = LayerMask.NameToLayer("Navigation");
    public static readonly int PerimeterLayer = LayerMask.NameToLayer("Perimeter");
    public static readonly int MovingLayer = LayerMask.NameToLayer("Moving");

    public static readonly int FastTravelLayer = LayerMask.NameToLayer("FastTravel");
    public static readonly int PostSplashLayer = LayerMask.NameToLayer("PostSplash");
    public static readonly int TutorialLayer = LayerMask.NameToLayer("Tutorial");
    public static readonly int SplashLayer = LayerMask.NameToLayer("Splash");

    public static readonly int LoadingLayer = LayerMask.NameToLayer("Loading");
    public static readonly int HiddenLayer = LayerMask.NameToLayer("Hidden");
    public static readonly int UnlitLayer = LayerMask.NameToLayer("Unlit");
    public static readonly int WaterLayer = LayerMask.NameToLayer("Water");

    public static readonly int AllMask = ~0;

    public static readonly int RuntimeMask = (1 << DefaultLayer) | (1 << EnvironmentLayer) | (1 << SplashLayer) | (1 << TutorialLayer) | (1 << UnlitLayer);
    public static readonly int LoadingMask = (1 << LoadingLayer);
    public static readonly int PostSplashMask = (1 << PostSplashLayer);
    public static readonly int UiMask = (1 << UiLayer);

    public static readonly int PerimeterMask = (1 << PerimeterLayer);
    public static readonly int EnvironmentMask = (1 << EnvironmentLayer) | (1 << PerimeterLayer);
    public static readonly int SurfaceMask = (1 << SelectableLayer) | (1 << EnvironmentLayer) | (1 << PerimeterLayer);
    public static readonly int NavigationMask = (1 << SelectableLayer) | (1 << EnvironmentLayer) | (1 << PerimeterLayer) | (1 << NavigationLayer);
    public static readonly int ControllerMask = (1 << SelectableLayer) | (1 << UiLayer) | (1 << EnvironmentLayer) | (1 << PerimeterLayer);
    public static readonly int SelectableMask = (1 << SelectableLayer) | (1 << UiLayer);

    public static readonly int SplashMask = (1 << SplashLayer) | (1 << TutorialLayer) | (1 << EnvironmentLayer) | (1 << PerimeterLayer);


    public static bool IsEnvironment(this Collider c) => c.IsLayer(EnvironmentLayer) || c.IsLayer(PerimeterLayer);
    public static bool IsEnvironment(this Renderer r) => r.IsLayer(EnvironmentLayer) || r.IsLayer(PerimeterLayer);
    public static bool IsNavigation(this Collider c) => c.IsLayer(NavigationLayer);
    public static bool IsNavigation(this Renderer r) => r.IsLayer(NavigationLayer);

    private static bool IsLayer<T>(this T component, int layer) where T : Component
    {
        if (component != null)
        {
            return component.gameObject.layer == layer;
        }
        return false;
    }
}
