﻿using System.Collections.Generic;
using System.Collections.Specialized;

public class Localisation : Singleton<Localisation>
{
    private Dictionary<string, string> m_Dictionary;
    private OrderedDictionary m_Order;

    public string this[string key]
    {
        get { return Get(key); }
        set { Set(key, value); }
    }

    public void LoadLanguage(Language language)
    {
        string path = GetLanguagePath(language);
        m_Dictionary = Json.JsonNet.ReadFromFile<Dictionary<string, string>>(path);
        m_Order = new OrderedDictionary();
        foreach (var entry in m_Dictionary)
        {
            m_Order.Add(entry.Key, entry.Value);
        }
    }

    public void SaveLanguage(Language language)
    {
        Json.Library.WriteToFile(m_Order, GetLanguagePath(language), true);
    }

    public void PurgeKeys(string startsWith)
    {
        var keys = new List<string>(m_Dictionary.Keys);
        for (int i = 0; i < keys.Count; ++i)
        {
            if (keys[i].ToLower().StartsWith(startsWith.ToLower()) == true)
            {
                m_Dictionary.Remove(keys[i]);
                m_Order.Remove(keys[i]);
                keys.RemoveAt(i);
                --i;
            }
        }
    }

    public string Get(string key) => m_Dictionary.Get(key) ?? string.Empty;

    public void Set(string key, string value)
    {
        m_Dictionary[key] = value;
        m_Order[key] = value;
    }

    private static string GetLanguagePath(Language language)
    {
        return $"{Device.StreamingPath}/data/languages/{language.ToString().ToLower()}";
    }

    public enum Language { English };
}
