﻿using System;
using UnityEngine;

public class AssetLoader
{
    private BundleLoader m_BundleLoader;
    private int m_Version = 0;

    public void Initialise(Action callback)
    {
        m_BundleLoader = new BundleLoader();
        m_BundleLoader.LoadAssetDatabase(callback);
    }

    public void Shutdown()
    {
        m_BundleLoader?.UnloadAll();
        m_BundleLoader = null;
    }

    public void LoadBundle(MonoBehaviour host, string bundleName, Action<AssetBundle> callback)
    {
        // load or retrieve bundle from loader
        m_BundleLoader.GetBundle(bundleName, m_Version, callback, host);
    }

    public void LoadAsset<T>(MonoBehaviour host, string assetName, string bundleName, Action<T> callback) where T : UnityEngine.Object
    {
        // load from resources or bundles?
        LoadBundle(host, bundleName, bundle =>
        {
            if (bundle != null)
            {
                // load asset from bundle
                host.WaitForOp(bundle.LoadAssetAsync<T>(assetName), op =>
                {
                    callback(op.asset as T);
                });
            }
            else
            {
                callback(null);
            }
        });
    }
}
